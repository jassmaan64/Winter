//
//  main.cpp
//  Program 6: Stock Analysis (Partner Coding Project)
//
//  Created by Jass Maan on 2/22/21.
//

#include <iostream>
#include "stock.h"
#include "stockList.h"
#include <deque>
using namespace std;

void getData(stockList &);

int main()
{
    stockList stockList1;
//    freopen("error.txt", "w", stderr);
    cout << fixed << setprecision(2) << showpoint;
    getData(stockList1);
    cout << "********* First Investor's Heaven **********\n********* Financial Report ********** \n" ;
  cout << "Stock Today Previous Percent\n";
  cout << "Symbol   Open   Close   High   Low     Close   Gain      Volume\n";
  cout << "------   ----   -----   ----   ---     -----   ----      ------\n";
    stockList1.print();
        /*
         * //declarations
        stockList stockList;
        freopen("error.txt", "w", stderr);
        cout << fixed << setprecision(2) << showpoint;

        getData(stockList);        //read external file data into stockList
        stockList.sortStockList(); //sorts stockList and generates indexByGain
      stockList.printBySymbol(); //prints alphabetically by symbol
      stockList.printByGain();   //prints high-to-low low by gain
        return 0;
         */
    return 0;
}
void getData(stockList &obj)
{
  ofstream fout("stockData.txt");
    fout << "ABC 123.45 130.95 132.00 125.00 120.50 10000\n"
         <<  "MSET 120.00 140.00 145.00 140.00 115.00 30920\n"
         <<  "AOLK 80.00 75.00 82.00 74.00 83.00 5000\n"
         <<  "CSO 100.00 102.00 105.00 98.00 101.00 25000\n"
    <<  "IBD 68.00 71.00 72.00 67.00 75.00 15000\n";
    fout.close();
  stock temp;
  ifstream fin ("stockData.txt");
  string name;
  deque <double> price1;
    double temps;
//  double gain;
  int vol;
  if(!fin) cout << "Error reading the external file!\n";
  
  while(fin >> name )
  {
    for(int i = 0 ; i < 5; i++)
      {
          fin >> temps;
          price1.push_back(temps);
      }
    fin >> vol;
    temp.setSymbol(name);
    temp.setPrice(price1);
    temp.setShare(vol);
    obj.insert(temp);
    for(int j = 0 ; j < 5; j++)price1.pop_back();

  }
}

//ABC 123.45 130.95 132.00 125.00 120.50 10000
//MSET 120.00 140.00 145.00 140.00 115.00 30920
//AOLK 80.00 75.00 82.00 74.00 83.00 5000
//CSO 100.00 102.00 105.00 98.00 101.00 25000
//IBD 68.00 71.00 72.00 67.00 75.00 15000
