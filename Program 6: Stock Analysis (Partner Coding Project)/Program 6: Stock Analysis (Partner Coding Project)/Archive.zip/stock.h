//
//  stock.h
//  Program 6: Stock Analysis (Partner Coding Project)
//
//  Created by Jass Maan on 2/22/21.
//

#ifndef stock_h
#define stock_h

#include <iostream>
#include <algorithm>
#include <fstream>
#include <deque>
#include <iomanip>
using namespace std;

/*
 * Set the stock information.
ii. Print the stock information.
iii. Show the different prices.
iv. Calculate and print the percent gain/loss.
v. Show the number of shares
 */
class stock {
private:
  string symbol;
    deque <double> price;
  int share;
public:
    stock()
    {symbol =" "; share =0;}
    stock(string s, deque <double> p, int sh)
  {symbol = s; for(int i=0; i < 4;i++)price[i]= p[i];share = sh;}
  void setSymbol(string s){symbol = s;};
  void setPrice(deque <double> p){price=p;};
  void setShare(int s){share = s;};
  string getSymbol(){return symbol;};
    deque <double> getPrice(){return price;}
  int getShare(){return share;};
  void print()
    {
      cout << setw(7) << left << symbol ;
      for(int i =0; i < price.size(); i++)
        cout << setw(7) << left <<price[i] << " ";
      cout << setw(5) << right << ((price[1]/price[4]) -1 ) *100 << "%";
      cout << "\t " << share << endl;
    }
};

/*
********* First Investor's Heaven **********
********* Financial Report **********
Stock Today Previous Percent
Symbol Open Close High Low Close Gain Volume
------ ---- ----- ---- --- ----- ---- ------
ABC 123.45 130.95 132.00 125.00 120.50 8.67% 10000
*/
//void stock::print()
//{
//   cout << "********* First Investor's Heaven **********\n********* Financial Report ********** \n" ;
//  cout << "Stock Today Previous Percent\n";
//  cout << "Symbol Open Close High Low Close Gain Volume\n";
//  cout << "------ ---- ----- ---- --- ----- ---- ------\n";
//  cout << symbol ;
//  for(int i =0; i < price.size(); i++)
//    cout << price[i] << " ";
//  cout << "\n";
//  cout << ((price[1]/price[4]) -1 ) *100 << " %";
//  cout << " " << share << endl;
//}
#endif /* stock_h */
