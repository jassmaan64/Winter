//
//  stockList.h
//  Program 6: Stock Analysis (Partner Coding Project)
//
//  Created by Jass Maan on 2/22/21.
//
#include <iostream>
#include <algorithm>
#include <fstream>
#include <deque>
#include <iomanip>
#include "stock.h"
using namespace std;

#ifndef stockList_h
#define stockList_h

class stockList: public stock
{
public:
  void insert(const stock& item){list.push_back(item);};
  //Function to insert a stock in the list.
  deque<stock> getList(){return list;}
  void print()
  {
    for(int i= 0; i < list.size(); i++)
    {
      list[i].stock::print();
    }
  }

private:
  deque<int> indexByGain;
  deque<stock> list; //vector to store the list //of stocks
};

#endif /* stockList_h */
